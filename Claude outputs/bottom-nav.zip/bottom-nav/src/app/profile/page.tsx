import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { AccountBar } from './account-bar';
import ProfileDetailCard from './profile-detail-card';

export const metadata = { title: 'Profile' };

export default async function ProfilePage() {
  const user = await getCurrentUser();

  // The bottom bar already points signed-out visitors at /login, but someone
  // can still reach this URL directly.
  if (!user) redirect('/login');

  return (
    <div className="flex flex-1 flex-col bg-zinc-50 dark:bg-black">
      <AccountBar user={user} />
      <ProfileDetailCard />
    </div>
  );
}
