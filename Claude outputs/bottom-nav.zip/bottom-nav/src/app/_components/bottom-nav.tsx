'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

/* =====================================================================
   Floating bottom navigation.

   Five destinations, profile last. The bar is hidden on focused flows —
   the posting wizard and the apply form — where a stray tap would throw
   away whatever the person had typed, and where their own sticky action
   bar already owns the bottom of the screen.
   ===================================================================== */

const HIDDEN_ON = [/^\/employer\/jobs\/new$/, /^\/jobs\/[^/]+\/apply$/];

function HomeIcon({ filled }: { filled: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" aria-hidden="true">
      <path
        d="M3.5 10.2 12 3.5l8.5 6.7V20a1 1 0 0 1-1 1h-5v-6h-5v6h-5a1 1 0 0 1-1-1v-9.8Z"
        fill={filled ? 'currentColor' : 'none'}
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function SearchIcon({ filled }: { filled: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" aria-hidden="true">
      <circle
        cx="11"
        cy="11"
        r="6.5"
        stroke="currentColor"
        strokeWidth={filled ? 2.4 : 1.7}
      />
      <path
        d="M16 16l4.5 4.5"
        stroke="currentColor"
        strokeWidth={filled ? 2.4 : 1.7}
        strokeLinecap="round"
      />
    </svg>
  );
}

function PostIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" aria-hidden="true">
      <rect x="3.2" y="3.2" width="17.6" height="17.6" rx="5" stroke="currentColor" strokeWidth="1.8" />
      <path d="M12 8.5v7M8.5 12h7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

function PostingsIcon({ filled }: { filled: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" aria-hidden="true">
      <rect
        x="2.5"
        y="7.5"
        width="19"
        height="12.5"
        rx="2.4"
        fill={filled ? 'currentColor' : 'none'}
        stroke="currentColor"
        strokeWidth="1.7"
      />
      <path
        d="M8.5 7.5V6A2.5 2.5 0 0 1 11 3.5h2A2.5 2.5 0 0 1 15.5 6v1.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.7"
      />
    </svg>
  );
}

export interface NavUser {
  initials: string;
}

export function BottomNav({ user }: { user: NavUser | null }) {
  const pathname = usePathname();

  if (HIDDEN_ON.some((pattern) => pattern.test(pathname))) return null;

  // Signed-out visitors land on sign-in rather than a profile they don't have.
  const profileHref = user ? '/profile' : '/login';

  const tabs = [
    { href: '/jobs', label: 'Jobs', active: pathname === '/jobs', icon: HomeIcon },
    {
      href: '/jobs?focus=search',
      label: 'Search',
      active: false,
      icon: SearchIcon,
    },
    { href: '/employer/jobs/new', label: 'Post', active: false, icon: null },
    {
      href: '/employer',
      label: 'Postings',
      active: pathname.startsWith('/employer'),
      icon: PostingsIcon,
    },
  ];

  const profileActive = pathname.startsWith('/profile');

  return (
    <>
      {/* Keeps the last of the page's content clear of the floating bar.
          A fixed element is out of flow, so without this the final card sits
          underneath it. */}
      <div aria-hidden="true" className="h-[88px] shrink-0" />

      <nav
        aria-label="Main"
        className="fixed bottom-4 left-1/2 z-30 w-[min(460px,calc(100%-32px))] -translate-x-1/2"
      >
        <ul className="flex items-center justify-around rounded-full border border-black/[.07] bg-white/90 px-2 py-2 shadow-lg shadow-black/[.1] backdrop-blur-xl dark:border-white/[.12] dark:bg-zinc-900/90 dark:shadow-black/40">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <li key={tab.label}>
                <Link
                  href={tab.href}
                  aria-label={tab.label}
                  aria-current={tab.active ? 'page' : undefined}
                  className={`flex h-11 w-11 items-center justify-center rounded-full transition-colors ${
                    tab.active
                      ? 'text-black dark:text-zinc-50'
                      : 'text-zinc-400 hover:text-zinc-700 dark:text-zinc-500 dark:hover:text-zinc-300'
                  }`}
                >
                  {Icon ? <Icon filled={tab.active} /> : <PostIcon />}
                </Link>
              </li>
            );
          })}

          <li>
            <Link
              href={profileHref}
              aria-label="Profile"
              aria-current={profileActive ? 'page' : undefined}
              className="flex h-11 w-11 items-center justify-center"
            >
              {user ? (
                <span
                  className={`flex h-8 w-8 items-center justify-center rounded-full bg-zinc-900 text-[11px] font-semibold text-white dark:bg-zinc-100 dark:text-zinc-900 ${
                    profileActive
                      ? 'ring-2 ring-zinc-900 ring-offset-2 ring-offset-white dark:ring-zinc-100 dark:ring-offset-zinc-900'
                      : ''
                  }`}
                >
                  {user.initials}
                </span>
              ) : (
                <svg viewBox="0 0 24 24" className="h-6 w-6 text-zinc-400" fill="none" aria-hidden="true">
                  <circle cx="12" cy="8.5" r="3.6" stroke="currentColor" strokeWidth="1.7" />
                  <path
                    d="M4.5 20.5c0-3.6 3.3-6 7.5-6s7.5 2.4 7.5 6"
                    stroke="currentColor"
                    strokeWidth="1.7"
                    strokeLinecap="round"
                  />
                </svg>
              )}
            </Link>
          </li>
        </ul>
      </nav>
    </>
  );
}
